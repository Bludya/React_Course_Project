const path = require('path');

module.exports = {
    development: {
      port: 4100,
      dbPath: 'mongodb://root:root123@ds127995.mlab.com:27995/project-manager-exam'
    },
    production: {}
};
